#!/bin/bash

#### BEGIN INIT INFO
# Info script e set variabili
  Author="Giuseppe Mangiameli @IT9ARZ"
# Data di rilascio: 11/03/2017
  Date="10/11/2017" #Revision
  Version="0.3"
  TitleScript="ctrlx"
# Description: Consente di vedere se un applicazione sta girando e di chiuderla
# Required:
#### END INIT INFO


#carico i parametri
source ~/it9app/x-eth-tool/script_util.sh


# Define Variable acmreset
acmreset=$(tput sgr0)

while getopts ivr name
do
        case $name in
          i)iopt=1;;
          v)vopt=1;;
          r)ropt=1;;
          *)echo "Argomento errato";;
        esac
done

if [[ ! -z $iopt ]]
then
{
wd=$(pwd)
basename "$(test -L "$0" && readlink "$0" || echo "$0")" > /tmp/scriptname
scriptname=$(echo -e -n $wd/ && cat /tmp/scriptname)
echo "Installazione in corso di $TitleScript"
su -c "cp $scriptname /usr/bin/$TitleScript" root && e_success "Script Installato! Esegui ora il Comando $TitleScript" || e_error "!! Errore nella fase di Installazione di $TitleScript"
}
fi

if [[ ! -z $vopt ]]
then
{
e_header_1 "$TitleScript versione: $Version   Revisione: $Date"
e_txt "Designed by $Author"
e_txt "Consente di vedere se un applicazione sta girando e chiuderla"
e_warning "Inserire Argomento "-i" per installare lo script"
e_warning "Inserire Argomento "-v" per vedere questa info"
e_warning "Inserire Argomento "-r" per rimuovere lo script"
}
fi

if [[ ! -z $ropt ]]
then
{
su -c "rm /usr/bin/$TitleScript" root && e_success "$TitleScript rimosso con successo!" || e_error "!! Errore nella rimozione di $TitleScript"
}
fi

if [[ $# -eq 0 ]]
then
{

e_header "CTRLX"
e_txt "Monitoraggio e chiusura applicazioni"
echo "================================="
echo "|by $Author |"
echo "================================="
echo "versione: $Version"
echo ""
e_txt "per annullare il comando, lasciare vuoto e premere invio."
echo -n "Scrivi l'applicazione da monitorare: "

#Recupero la risposta
read AP

if [ ${AP:-e} = "e" ];
then
{
        e_error "comando annullato"
}
else
{
echo ""
echo "  PID USER     S      TIME+ COMMAND"
ps ax | grep $AP

echo ""
e_txt "Digita il PID del programma da chiudere"
e_txt "per annullare il comando, lasciare vuoto e premere invio."
echo -n "PID: "

#Recupero la risposta
read ES

if [ ${ES:-y} = "y" ];
then
{
        e_error "comando annullato"
}
else
{
sudo kill $ES
}
fi
}
fi

}
fi

shift $(($OPTIND -1))
