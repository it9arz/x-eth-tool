#!/bin/bash
#### BEGIN INIT INFO
  Author="Giuseppe Mangiameli @ IT9ARZ"
# Data di rilascio: 08/04/2016 
  Date="02/10/2016" #Revision
  Version="1.0.1"
  TitleScript="umountx"
# Description: Smontare una partizione
#### END INIT INFO

#carico i parametri
source ~/it9app/x-eth-tool/script_util.sh


while getopts ivr name
do
        case $name in
          i)iopt=1;;
          v)vopt=1;;
          r)ropt=1;;
          *)echo "Argomento errato";;
        esac
done

if [[ ! -z $iopt ]]
then
{
wd=$(pwd)
basename "$(test -L "$0" && readlink "$0" || echo "$0")" > /tmp/scriptname
scriptname=$(echo -e -n $wd/ && cat /tmp/scriptname)
echo "Installazione in corso di $TitleScript"
su -c "cp $scriptname /usr/bin/$TitleScript" root && e_success "Script Installato, esegui ora il Comando $TitleScript" || e_error "Errore nella fase di Installazione di $TitleScript"
}
fi

if [[ ! -z $vopt ]]
then
{
e_header_1 "$TitleScript versione: $Version   Revision: $Date"
e_txt "Designed by $Author"
e_txt "Script per smontare unità"
e_warning "Inserire Argomento "-i" per installare lo script"
e_warning "Inserire Argomento "-v" per vedere questa info"
e_warning "Inserire Argomento "-r" per rimuovere lo script"
}
fi

if [[ ! -z $ropt ]]
then
{
su -c "rm /usr/bin/$TitleScript" root && e_success "$TitleScript rimosso con successo" || e_error "Errore nella rimozione di $TitleScript"
}
fi

if [[ $# -eq 0 ]]
then
{
#visualizo partizioni montate
df -h

echo -n "Srivi la partizione da smontare (es. /mnt/pi) : "
#Recupero la risposta
read Partition

fusermount -u $Partition

}
fi
shift $(($OPTIND -1))
